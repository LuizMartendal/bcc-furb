package infra;

public interface Controller {
}
