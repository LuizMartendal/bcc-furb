import infra.Route;
import infra.Runner;

public class Server {

    public static void main(String[] args) {
        Runner.run(new Route());
    }

}
