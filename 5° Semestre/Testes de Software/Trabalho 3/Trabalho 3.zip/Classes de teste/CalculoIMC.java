/* 
 Bábara Moro
 Luiz Henrique Martendal
 Maria Júlia Testoni
 Nícolas Zimermann
 */

public class CalculoIMC {

	public double calcular(double altura, double peso) {
		return 0;
	}

	public double calcular(String altura, String peso) {
		// TODO Auto-generated method stub
		return 0;
	}

}
