package br.furb.restapifurb.enuns;

public enum Roles {

    ADMIN,
    USER
}
